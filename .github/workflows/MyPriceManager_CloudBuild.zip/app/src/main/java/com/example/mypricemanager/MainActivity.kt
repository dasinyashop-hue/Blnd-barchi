package com.example.mypricemanager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Locale

data class Product(
    val id: String,
    val name: String,
    val buy: Long,
    val sell: Long,
    val quantity: Int,
    val photo: String
) {
    val profit: Long get() = sell - buy
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KurdishPriceApp(this) }
    }
}

private fun loadProducts(context: Context): MutableList<Product> {
    val raw = context.getSharedPreferences("inventory", Context.MODE_PRIVATE)
        .getString("products", "[]") ?: "[]"
    val arr = JSONArray(raw)
    val result = mutableListOf<Product>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        result.add(Product(
            o.optString("id"), o.optString("name"), o.optLong("buy"),
            o.optLong("sell"), o.optInt("quantity"), o.optString("photo")
        ))
    }
    return result
}

private fun saveProducts(context: Context, products: List<Product>) {
    val arr = JSONArray()
    products.forEach {
        arr.put(JSONObject().put("id", it.id).put("name", it.name)
            .put("buy", it.buy).put("sell", it.sell)
            .put("quantity", it.quantity).put("photo", it.photo))
    }
    context.getSharedPreferences("inventory", Context.MODE_PRIVATE)
        .edit().putString("products", arr.toString()).apply()
}

private fun makeQr(text: String): Bitmap {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 420, 420)
    val bmp = Bitmap.createBitmap(420, 420, Bitmap.Config.ARGB_8888)
    for (x in 0 until 420) for (y in 0 until 420) {
        bmp.setPixel(x, y, if (matrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE)
    }
    return bmp
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KurdishPriceApp(context: Context) {
    var products by remember { mutableStateOf(loadProducts(context)) }
    var name by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var photoUri by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var selectedQr by remember { mutableStateOf<Product?>(null) }
    var error by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) photoUri = uri.toString()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Color(0xFF176B55),
                secondary = Color(0xFFDAA520),
                background = Color(0xFFF5F7F6)
            )
        ) {
            Scaffold(
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text("نرخی کاڵاکان", fontWeight = FontWeight.Bold) }
                    )
                }
            ) { padding ->
                LazyColumn(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFF5F7F6)).padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("زیادکردنی کاڵای نوێ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                OutlinedTextField(name, { name = it }, label = { Text("ناوی کاڵا") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(buy, { buy = it.filter(Char::isDigit) }, label = { Text("نرخی کڕین (دینار)") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                    OutlinedTextField(sell, { sell = it.filter(Char::isDigit) }, label = { Text("نرخی فرۆشتن (دینار)") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                }
                                OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, label = { Text("ژمارەی دانە") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (photoUri.isBlank()) "وێنەی کاڵا هەڵبژێرە" else "وێنە هەڵبژێردرا")
                                }
                                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                                Button(
                                    onClick = {
                                        val b = buy.toLongOrNull()
                                        val s = sell.toLongOrNull()
                                        val q = quantity.toIntOrNull()
                                        if (name.isBlank() || b == null || s == null || q == null || q < 0) {
                                            error = "تکایە هەموو زانیارییەکان بە دروستی پڕبکەرەوە"
                                        } else {
                                            val id = "KAL-${System.currentTimeMillis().toString().takeLast(8)}"
                                            val p = Product(id, name.trim(), b, s, q, photoUri)
                                            products = (products + p).toMutableList()
                                            saveProducts(context, products)
                                            name = ""; buy = ""; sell = ""; quantity = "1"; photoUri = ""; error = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("زیادکردنی کاڵا") }
                            }
                        }
                    }
                    item {
                        Text("کاڵاکان (${products.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(search, { search = it }, label = { Text("گەڕان بە ناو یان کۆد") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    items(products.filter { it.name.contains(search, true) || it.id.contains(search, true) }, key = { it.id }) { p ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("کۆد: ${p.id}", color = Color(0xFF176B55))
                                Text("کڕین: ${p.buy} د.ع   |   فرۆشتن: ${p.sell} د.ع")
                                Text("قازانج: ${p.profit} د.ع   |   دانە: ${p.quantity}")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { selectedQr = p }, modifier = Modifier.weight(1f)) { Text("پیشاندانی QR") }
                                    OutlinedButton(onClick = {
                                        products = products.filterNot { it.id == p.id }.toMutableList()
                                        saveProducts(context, products)
                                    }) { Text("سڕینەوە") }
                                }
                            }
                        }
                    }
                    if (products.isEmpty()) item {
                        Text("هێشتا هیچ کاڵایەک زیاد نەکراوە.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Color.Gray)
                    }
                }
            }
            selectedQr?.let { p ->
                AlertDialog(
                    onDismissRequest = { selectedQr = null },
                    title = { Text("کۆدی کاڵا") },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Image(bitmap = remember(p.id) { makeQr(p.id).asImageBitmap() }, contentDescription = "QR code", modifier = Modifier.size(220.dp))
                            Text(p.id, fontWeight = FontWeight.Bold)
                            Text(p.name)
                        }
                    },
                    confirmButton = { TextButton(onClick = { selectedQr = null }) { Text("داخستن") } }
                )
            }
        }
    }
}
